//INMPORTAM FUNCIONS DE FIREBASE
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js"
import { getDatabase, ref, push, onValue, remove } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-database.js"

const appSettings = {
  databaseURL: "https://peliculas-ab9a8-default-rtdb.europe-west1.firebasedatabase.app/"
}
const app = initializeApp(appSettings);
const database = getDatabase(app);
const peliculesInDB = ref(database, "pelicules");

 
const inputFieldEl = document.getElementById("peli");
const addButtonEl = document.getElementById("button");
const peliculeslistEl = document.getElementById("pelicules");
//const img = document.getElementById("img");
//const button_file = document.getElementById("file");


onValue(peliculesInDB, function (snapshot) {
  if (snapshot.exists()) {
    clearListEl();
    let itemsArray = Object.entries(snapshot.val())
    clearinputFieldEl();
    for (let i = 0; i < itemsArray.length; i++) {
      appendItemToPeliculesListEl(itemsArray[i]);
    }
  }
  else {
    peliculeslistEl.innerHTML = "No items yet"
  }

})

//Plataformes
window.addEventListener("DOMContentLoaded", () => {
  const select = document.getElementById('select1');
  select.addEventListener("click", () => {
    let selected = document.getElementById('select1').selectedOptions;
    for (let i = 0; i < selected.length; i++) {
      console.log(selected[i].value);
      if (i == selected.length - 1) {
        document.getElementById('plataforma1').innerHTML += " " + selected[i].value;
      }
    }
  });
});

window.addEventListener("DOMContentLoaded", () => {
  const select = document.getElementById('select2');
  select.addEventListener("click", () => {
    let selected = document.getElementById('select2').selectedOptions;
    for (let i = 0; i < selected.length; i++) {
      console.log(selected[i].value);
      if (i == selected.length - 1) {
        document.getElementById('plataforma2').innerHTML += " " + selected[i].value;
      }
    }
  });
});

// afegir a la database
addButtonEl.addEventListener('click', function () {
  var nom = document.getElementById('nom').value;
  var data = document.getElementById('dataestrena').value;
  var actor1 = document.getElementById('actor1').value;
  var actor2 = document.getElementById('actor2').value;
  var actor3 = document.getElementById('actor3').value;
  var actor4 = document.getElementById('actor4').value;
  var director = document.getElementById('director').value;
  var resum = document.getElementById('resum').value;
  var valoracio = document.getElementById('valoracio').value;
  var plataforma1 = document.getElementById('select1').value;
  var plataforma2 = document.getElementById('select2').value;
  var url = document.getElementById('imageUrl').value;
  

  let peli = {
    nom: nom,
    data: data,
    actor1: actor1,
    actor2: actor2,
    actor3: actor3,
    actor4: actor4,
    director: director,
    resum: resum,
    valoracio: valoracio,
    plataforma1: plataforma1,
    plataforma2: plataforma2,
    url: url
  }


  push(peliculesInDB, peli);
  clearinputFieldEl();

});



//borrar el valor del formulari
function clearinputFieldEl() {
  document.getElementById('nom').value = "";
  document.getElementById('dataestrena').value = "";
  document.getElementById('actor1').value = "";
  document.getElementById('actor2').value = "";
  document.getElementById('actor3').value = "";
  document.getElementById('actor4').value = "";
  document.getElementById('director').value = "";
  document.getElementById('resum').value = "";
  document.getElementById('valoracio').value = "";
  document.getElementById('plataforma1').value = "";
  document.getElementById('plataforma2').value = "";
  document.getElementById('imageUrl').value="";
 
};

//Borrar la llista de pelicules
function clearListEl() {
  peliculeslistEl.innerHTML = "";
};

function clearpeliculeslistEl() {
  peliculesInDB.innerHTML = document.getElementById("pelicules");
};

//  Afegir element de la llista de la compra
function appendItemToPeliculesListEl(item) {
  console.log(item)
  let itemId = item[0];
  let contenidor = document.createElement("div");
  contenidor.className += "peli";

  let nom = document.createElement("p");
  nom.innerHTML  = item[1].nom;
  contenidor.appendChild(nom);

  let data = document.createElement("p");
  data.innerHTML = item[1].data;
  contenidor.appendChild(data);

  let actor1 = document.createElement("p");
  actor1.innerHTML = item[1].actor1;
  contenidor.appendChild(actor1);

  let actor2 = document.createElement("p");
  actor2.innerHTML = item[1].actor2;
  contenidor.appendChild(actor2);

  let actor3 = document.createElement("p");
  actor3.innerHTML = item[1].actor3;
  contenidor.appendChild(actor3);

  let actor4 = document.createElement("p");
  actor4.innerHTML = item[1].actor4;
  contenidor.appendChild(actor4);

  let director = document.createElement("p");
  director.innerHTML = item[1].director;
  contenidor.appendChild(director);

  let resum = document.createElement("p");
  resum.innerHTML = item[1].resum;
  contenidor.appendChild(resum);

  let valoracio = document.createElement("p");
  valoracio.innerHTML = item[1].valoracio;
  contenidor.appendChild(valoracio);

  let plataforma1 = document.createElement("p");
  plataforma1.innerHTML = item[1].plataforma1;
  contenidor.appendChild(plataforma1);

  let plataforma2 = document.createElement("p");
  plataforma2.innerHTML = item[1].plataforma2;
  contenidor.appendChild(plataforma2);

  let imageUrl = document.createElement("img");
  imageUrl.src = item[1].url;
  contenidor.appendChild(imageUrl);


  peliculeslistEl.append(contenidor);

  const exactLocationofitemDB = ref(database, `pelicules/${itemId}`);
  contenidor.addEventListener('click', function () {
    let vols = confirm("Vols eliminar-ho?")
    if (vols) {
    remove(exactLocationofitemDB);
    }
  });
}

//Valoració 
var slider = document.getElementById("valoracio");
var output = document.getElementById("value");

output.innerHTML = slider.value;

slider.oninput = function(){
  output.innerHTML = this.value;
};



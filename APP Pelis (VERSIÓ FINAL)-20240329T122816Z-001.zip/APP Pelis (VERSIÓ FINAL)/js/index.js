import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js"
import { getDatabase, ref, push, onValue, remove } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-database.js"


const appSettings = {
  databaseURL: "https://peliculas-ab9a8-default-rtdb.europe-west1.firebasedatabase.app/"
}
const app = initializeApp(appSettings)
const database = getDatabase(app)
const peliculesInDB = ref(database, "pelicules")


const inputFieldEl = document.getElementById("text");
const addButtonEl = document.getElementById("button");
const peliculeslistEl = document.getElementById("pelicules");


onValue(peliculesInDB, function (snapshot) {
  if (snapshot.exists()) {
    clearListEl();
    let itemsArray = Object.entries(snapshot.val())
    clearpeliculeslistEl();
    for (let i = 0; i < itemsArray.length; i++) {
      appendItemToPeliculesListEl(itemsArray[i]);
    }
  }
  else {
    peliculeslistEl.innerHTML = "No items yet"
  }

})

addButtonEl.addEventListener('click', function () {
  let inputValue = inputFieldEl.value;
  push(peliculesInDB, inputValue);

  clearInputfieldEl();
  clearinputValue();


  console.log(`${inputValue} added to database`);
})
//
function clearInputfieldEl() {
  inputFieldEl.value = "";
}

//  Afegir element de la llista de la compra
function appendItemToPeliculesListEl(item) {

  let htmlEl = document.createElement("li");
  let itemId = item[0];
  let itemValue = item[1];
  htmlEl.textContent = itemValue;
  let text;
  const exactLocationofitemDB = ref(database, `pelicules/${itemId}`);
  htmlEl.addEventListener('click', function () {
    let vols = confirm("Vols eliminar-ho?")
    if (vols) {
      remove(exactLocationofitemDB);
    }

  })
  peliculeslistEl.append(htmlEl);
}

//shoppinglistEl.innerHTML += `<li>${item}</li>`

//Borrar element llista compra

function clearpeliculeslistEl() {
  peliculesInDB.innerHTML = document.getElementById("pelicules");
}

//Borrar valor de l'element de la llista de la compra
function clearinputValue() {
  inputFieldEl.value = "";
}
//Borrar 
function clearListEl() {
  peliculeslistEl.innerHTML = "";
}

//funció pel·lícula
function Peli(nom, dataestrena, actors, director, resum, valoracio, plataformes) {
  this.nom = nom;
  this.dataestrena = dataestrena;
  this.actors = actors;
  this.director = director;
  this.resum = resum;
  this.valoracio = valoracio;
  this.plataformes = plataformes;

};

//informació de la peli1 
const button1 = document.getElementById("peli1");
const peli1 = new Peli('SONIC', '26-06-2020', 'Jim Carrey, Ben Schwartz, James Marsden, Tika Sumpter', 'Jeff Fowler', ' Sonic the Hedgehog és una pel·lícula de comèdia, acció i aventura nord-americana-japonesa del 2020 basada en la franquícia de videojocs del mateix nom publicada per Sega.', '71%', ' Amazon Prime Video, Youtube, Google Play Pel·lícules');

button1.addEventListener('click', function () {
  console.log(peli1);
  document.querySelector("#nom1").innerHTML = peli1.nom;
  document.querySelector("#dataestrena1").innerHTML = peli1.dataestrena;
  document.querySelector("#actors1").innerHTML = peli1.actors;
  document.querySelector("#director1").innerHTML = peli1.director;
  document.querySelector("#resum1").innerHTML = peli1.resum;
  document.querySelector("#valoracio1").innerHTML = peli1.valoracio;
  document.querySelector("#plataformes1").innerHTML = peli1.plataformes;



});
document.body.appendChild(button1);


//informació de la peli2
const button2 = document.getElementById("peli2");
const peli2 = new Peli('SOLO EN CASA', '21/12/1990', 'Macaulay Culkin, Joe Pesci, Daniel Stern, Kieran Culkin', 'Chris Columbus', 'Sol a casa és una pel·lícula estatunidenca del 1990, escrita i produïda per John Hughes i dirigida per Chris Columbus. La pel·lícula està protagonitzada per Macaulay Culkin com Kevin McCallister, un nen de vuit anys, qui es queda sol a casa per error quan la seva família se-n va de vacances a París per Nadal.', ' 90%', 'Google Play Pel·lícules, Apple TV, Movistar Plus ');

button2.addEventListener('click', function () {
  console.log(peli2);
  document.querySelector("#nom2").innerHTML = peli2.nom;
  document.querySelector("#dataestrena2").innerHTML = peli2.dataestrena;
  document.querySelector("#actors2").innerHTML = peli2.actors;
  document.querySelector("#director2").innerHTML = peli2.director;
  document.querySelector("#resum2").innerHTML = peli2.resum;
  document.querySelector("#valoracio2").innerHTML = peli2.valoracio;
  document.querySelector("#plataformes2").innerHTML = peli2.plataformes;
});
document.body.appendChild(button2);
